package com.appsrox.remindme;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

//import com.example.demologin.MainActivity;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class registration extends Activity {
    String user;
    String passw;
    InputStream is;
    String result=null;
    String line=null;
    int code;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        ImageButton submit=(ImageButton)findViewById(R.id.imageButton1);
        final EditText username=(EditText)findViewById(R.id.editText1);
        final EditText pass=(EditText)findViewById(R.id.editText2);
        submit.setOnClickListener(new View.OnClickListener() {

            @SuppressLint("NewApi")
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                user=username.getText().toString();
                passw=pass.getText().toString();
                if((user.isEmpty()) ||( passw.isEmpty()))
                {

                    Toast.makeText(getApplicationContext(),"Enter  details", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(getApplicationContext(),"Entered  details", Toast.LENGTH_SHORT).show();
                    Thread conn=new Thread(new Runnable()
                    {

                        @Override
                        public void run() {
                            // TODO Auto-generated method stub

                            verify();
                        }
                    });
                    conn.start();

                }


            }});



    }
    public void verify()
    {
        ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();

        nameValuePairs.add(new BasicNameValuePair("user",user));
        nameValuePairs.add(new BasicNameValuePair("passw",passw));

        try
        {
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost("http://192.168.0.101/yello/check.php");
            httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
            HttpResponse response = httpclient.execute(httppost);
            HttpEntity entity = response.getEntity();
            is = entity.getContent();
            Log.e("pass 1", "connection success ");
        }
        catch(Exception e)
        {
            Log.e("Fail 1", e.toString());
            Toast.makeText(getApplicationContext(), "Invalid IP Address",
                    Toast.LENGTH_LONG).show();
        }

        try
        {
            BufferedReader reader = new BufferedReader(new InputStreamReader(is,"iso-8859-1"),8);
            StringBuilder sb = new StringBuilder();
            while ((line = reader.readLine()) != null)
            {
                sb.append(line + "\n");
            }
            is.close();
            result = sb.toString();
            Log.e("pass 2", "connection success ");
        }
        catch(Exception e)
        {
            Log.e("Fail 2", e.toString());
        }

        try
        {
            JSONObject json_data = null;
            try{
                json_data = new JSONObject(result);
                // Log.e("tagconvertstr", "["+result+"]");
            }
            catch(JSONException j){Log.e("JSON Parser", "Error parsing data [" + j.getMessage()+"] "+result);};

            code=(json_data.getInt("code"));

            if(code==1)
            {

                registration.this.runOnUiThread(new Runnable() {
                    public void run() {
                        Toast.makeText(getBaseContext(), "User Verified!! Welcome",Toast.LENGTH_SHORT).show();

                    }

                });
                //View v = null;
                Intent i = new Intent(this, com.appsrox.remindme.Menu.class);
                startActivity(i);

            }
            else
            {
                registration.this.runOnUiThread(new Runnable(){
                    public void run(){
                        Toast.makeText(getBaseContext(), "Invalid username and password combination",Toast.LENGTH_LONG).show();
                    }
                });
            }
        }
        catch(Exception e)
        {
            Log.e("Fail 3", e.toString());
        }
    }


    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}