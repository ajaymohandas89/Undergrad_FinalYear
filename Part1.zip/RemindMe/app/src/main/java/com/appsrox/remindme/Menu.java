package com.appsrox.remindme;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class Menu extends Activity {
    ImageButton rem;
    ImageButton links;
    ImageButton aboutus;
    ImageButton applock;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        rem=(ImageButton)findViewById(R.id.rem);
        links=(ImageButton)findViewById(R.id.links);
        aboutus=(ImageButton)findViewById(R.id.aboutus);
        applock=(ImageButton)findViewById(R.id.applock);

        rem.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub


                final Intent i = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(i);
            }
        });
        links.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub


                final Intent i = new Intent(getApplicationContext(), links.class);
                startActivity(i);
            }
        });
        aboutus.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub


                final Intent i = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(i);
            }
        });

        applock.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub


                final Intent i = new Intent(getApplicationContext(), SMSSenderActivity.class);
                startActivity(i);
            }
        });

    }


}
