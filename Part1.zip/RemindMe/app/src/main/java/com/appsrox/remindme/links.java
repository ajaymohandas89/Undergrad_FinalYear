package com.appsrox.remindme;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.ImageButton;

public class links extends Activity {

    ImageButton amazon;
    ImageButton bms;
    ImageButton foodpanda;
    ImageButton pnr;
    ImageButton paytm;
    ImageButton zomato;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_links);
        amazon=(ImageButton)findViewById(R.id.amazon);
        bms=(ImageButton)findViewById(R.id.bms);
        paytm=(ImageButton)findViewById(R.id.paytm);
        foodpanda=(ImageButton)findViewById(R.id.foodpanda);
        pnr=(ImageButton)findViewById(R.id.pnr);
        zomato=(ImageButton)findViewById(R.id.zomato);


        amazon.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("http://www.amazon.in/"));
                startActivity(intent);
            }
        });

        bms.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("http://in.bookmyshow.com/"));
                startActivity(intent);
            }
        });

        foodpanda.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.foodpanda.in/"));
                startActivity(intent);
            }
        });

        pnr.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("http://www.indianrail.gov.in/pnr_Enq.html"));
                startActivity(intent);
            }
        });

        paytm.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://paytm.com/"));
                startActivity(intent);
            }
        });

        zomato.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.zomato.com/"));
                startActivity(intent);
            }
        });

    }

}
