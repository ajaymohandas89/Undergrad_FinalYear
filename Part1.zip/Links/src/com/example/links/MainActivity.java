package com.example.links;

import android.support.v7.app.ActionBarActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends ActionBarActivity {
	ImageView image1,image2,image3,image4;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
	
	ImageView image1 = (ImageView)findViewById(R.id.imageView1);
	image1.setOnClickListener(new View.OnClickListener(){
	    public void onClick(View v){
	        Intent intent = new Intent();
	        intent.setAction(Intent.ACTION_VIEW);
	        intent.addCategory(Intent.CATEGORY_BROWSABLE);
	        intent.setData(Uri.parse("http://www.amazon.in/"));
	        startActivity(intent);
	    }
	});
	ImageView image2 = (ImageView)findViewById(R.id.imageView2);
	image2.setOnClickListener(new View.OnClickListener(){
	    public void onClick(View v){
	        Intent intent = new Intent();
	        intent.setAction(Intent.ACTION_VIEW);
	        intent.addCategory(Intent.CATEGORY_BROWSABLE);
	        intent.setData(Uri.parse("http://in.bookmyshow.com/"));
	        startActivity(intent);
	    }
	});
	ImageView image3 = (ImageView)findViewById(R.id.imageView3);
	image3.setOnClickListener(new View.OnClickListener(){
	    public void onClick(View v){
	        Intent intent = new Intent();
	        intent.setAction(Intent.ACTION_VIEW);
	        intent.addCategory(Intent.CATEGORY_BROWSABLE);
	        intent.setData(Uri.parse("http://www.flipkart.com/"));
	        startActivity(intent);
	    }
	});
	ImageView image4 = (ImageView)findViewById(R.id.imageView4);
	image4.setOnClickListener(new View.OnClickListener(){
	    public void onClick(View v){
	        Intent intent = new Intent();
	        intent.setAction(Intent.ACTION_VIEW);
	        intent.addCategory(Intent.CATEGORY_BROWSABLE);
	        intent.setData(Uri.parse("https://www.zomato.com/india"));
	        startActivity(intent);
	    }
	});}
}
