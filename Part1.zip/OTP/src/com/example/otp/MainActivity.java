package com.example.otp;

import java.util.Random;

import android.support.v7.app.ActionBarActivity;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
       
import java.util.Random;

public class MainActivity extends Activity implements View.OnClickListener {
    EditText e;
    Button b1,b2;
    int otp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e = (EditText) findViewById(R.id.edt1);
        b1 = (Button) findViewById(R.id.buttonToast);
        b2 = (Button)findViewById(R.id.button1);
        b1.setOnClickListener(this);
        b2.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v == b1){
            otp = generateOTP();
            Toast.makeText(this, "Your OTP code is "+otp, Toast.LENGTH_LONG).show();
        }
        else if(v== b2){
            if(Integer.parseInt(e.getText().toString()) == otp){
                Toast.makeText(this, "Match found", Toast.LENGTH_LONG).show();
                 
                
                 Intent i = new Intent(MainActivity.this,ToActivity.class);
                 startActivity(i);
                
            }
            else{
                Toast.makeText(this, "Match not found", Toast.LENGTH_LONG).show();
            }
        }
    }

    public int generateOTP() {
        int otp = 0;
        int [] otpArray = {1234,2222,3785,4690,5551,6254,7901,8231,93245,1110,1231,2919,1330};
        Random r= new Random();
        int i = r.nextInt(otpArray.length);
        otp = otpArray[i];
        return otp;
    }
}
