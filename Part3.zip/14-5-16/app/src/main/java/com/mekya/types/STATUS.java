package com.mekya.types;

public enum STATUS {
	ONLINE, OFFLINE, BUSY, INVISIBLE, AWAY, UNAPPROVED
}
