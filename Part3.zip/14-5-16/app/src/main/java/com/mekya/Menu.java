package com.mekya;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class Menu extends Activity {
    ImageButton rem;
    ImageButton links;
    ImageButton aboutus;
    ImageButton mess;
    ImageButton sms;
    ImageButton off;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        rem=(ImageButton)findViewById(R.id.rem);
        links=(ImageButton)findViewById(R.id.links);
        aboutus=(ImageButton)findViewById(R.id.aboutus);
        mess=(ImageButton)findViewById(R.id.chat);
        sms=(ImageButton)findViewById(R.id.applock);
        off=(ImageButton)findViewById(R.id.offline);
      rem.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub


                final Intent i = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(i);
            }
        });
        off.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub


                final Intent i = new Intent(getApplicationContext(), SMS.class);
                startActivity(i);
            }
        });
        links.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub


                final Intent i = new Intent(getApplicationContext(), links.class);
                startActivity(i);
            }
        });

        sms.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub

                final Intent i = new Intent(getApplicationContext(), SMSSenderActivity.class);
                startActivity(i);
            }
        });

        mess.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub


                final Intent i = new Intent(getApplicationContext(), Login.class);
                startActivity(i);
            }
        });
        aboutus.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub


                final Intent i = new Intent(getApplicationContext(), aboutus.class);
                startActivity(i);
            }
        });




    }


}
