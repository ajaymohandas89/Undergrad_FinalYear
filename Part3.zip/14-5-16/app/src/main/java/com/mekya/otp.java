package com.mekya;

import java.util.Random;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Random;

public class otp extends Activity implements View.OnClickListener {
    EditText e;
    Button b1,b2;
    int otp;
    SharedPreferences pref;
    SharedPreferences.Editor editor;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pref = getSharedPreferences("testapp", MODE_PRIVATE);
       editor = pref.edit();
        String getStatus=pref.getString("register", "nil");
        if(getStatus.equals("true"))
        {
            Intent i = new Intent(otp.this, applock.class);
            startActivity(i);
        }
        else {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_otp);
            e = (EditText) findViewById(R.id.edt1);
            b1 = (Button) findViewById(R.id.buttonToast);
            b2 = (Button)findViewById(R.id.button1);
            b1.setOnClickListener(this);
            b2.setOnClickListener(this);
        }


    }

    @Override
    public void onClick(View v) {
        if(v == b1){
            otp = generateOTP();
            Toast.makeText(this, "Your OTP code is "+otp, Toast.LENGTH_LONG).show();
        }
        else if(v== b2){
            if(Integer.parseInt(e.getText().toString()) == otp){
                Toast.makeText(this, "Match found", Toast.LENGTH_LONG).show();
                editor.putString("applock", "hello");
                editor.commit();
                editor.putString("register","true");
                editor.commit();

                Intent i = new Intent(otp.this, applock_select.class);
                startActivity(i);

            }
            else{
                Toast.makeText(this, "Match not found", Toast.LENGTH_LONG).show();
            }
        }
    }

    public int generateOTP() {
        int otp = 0;
        int [] otpArray = {1234,2222,3785,4690,5551,6254,7901,8231,93245,1110,1231,2919,1330};
        Random r= new Random();
        int i = r.nextInt(otpArray.length);
        otp = otpArray[i];
        return otp;
    }
}
