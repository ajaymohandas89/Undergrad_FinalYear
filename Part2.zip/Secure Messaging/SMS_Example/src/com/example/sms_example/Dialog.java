package com.example.sms_example;

import android.R.layout;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Dialog extends Activity implements View.OnClickListener {

	String message;
	  private EditText password;
	  private Button btnSubmit;
public static int flag=0;
	  @Override
	  public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.password_dialog);
		password = (EditText) findViewById(R.id.txtPassword);	
		btnSubmit = (Button) findViewById(R.id.btnSubmit);
		
		btnSubmit.setOnClickListener(this);
	  }

	

	@Override
	public void onClick(View v) {
		if(v==btnSubmit)
		{
			
			 message=password.getText().toString();
			if(message.equals("ajaymohandas89"))
			{
				flag=1;
				 Toast.makeText(this, "Match found", Toast.LENGTH_LONG).show();
				finish();
			}
			else
				 Toast.makeText(this, "Match not found", Toast.LENGTH_LONG).show();
		}
	}
	}