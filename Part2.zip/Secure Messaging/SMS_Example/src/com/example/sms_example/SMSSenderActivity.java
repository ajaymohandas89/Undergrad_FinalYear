package com.example.sms_example;




import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.app.AlertDialog.Builder;
import android.app.AlertDialog;
public class SMSSenderActivity extends Activity implements View.OnClickListener {
    /** Called when the activity is first created. */
	EditText txtMessage,txtPhone,txt;
	char c;
	char b[];
	Button btnSend,btn;
	BroadcastReceiver smsSentReceiver, smsDeliveredReceiver;
	String message;
	String a;
	char bc[];
	char c1;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        txtMessage=(EditText)findViewById(R.id.editText1);
        txtPhone=(EditText)findViewById(R.id.editText2);
        txt=(EditText)findViewById(R.id.editText3);
        btnSend=(Button)findViewById(R.id.button1);
        btn=(Button)findViewById(R.id.button2);
        btnSend.setOnClickListener(this);
        btn.setOnClickListener(this); 
        
    }
 	 								public void onClick(View argo)
 	 									{	
 	 									if(argo==btnSend)
 	 									{
							        		SmsManager sms=SmsManager.getDefault();
							        		String phone=txtPhone.getText().toString();
							        		 message=txtMessage.getText().toString();
							        		 b=new char[message.length()];
							        		 for ( int i = 0; i < message.length(); i++ )

							        			{  
							        			           c = message.charAt(i);

							        			         c=(char) (c+3);
							        			            b[i]=c;
							        			         }
							        			
							        			String z = new String(b);
							        			txt.setText(z.toString());
							        		PendingIntent piSent=PendingIntent.getBroadcast(this, 0, new Intent("SMS_SENT"), 0);
							        		PendingIntent piDelivered=PendingIntent.getBroadcast(this, 0, new Intent("SMS_DELIVERED"), 0);
							        		sms.sendTextMessage(phone, null, message, piSent, piDelivered);
 	 									}
 	 									else if(argo==btn)
 	 									{
 	 										Intent i1 = new Intent(SMSSenderActivity.this,Dialog.class);
 	 						                 startActivity(i1);
 	 						                 
 	 						                 if(Dialog.flag==1){
											 a=txt.getText().toString();
											 bc=new char[txt.length()];
											 for ( int i = 0; i < a.length(); i++ )

												{  
												           c1 = a.charAt(i);

												         c1=(char) (c1-3);
												            bc[i]=c1;
												         }
												
												String z11 = new String(bc);
												txt.setText(z11.toString());
 	 						                 }
											
										}
							     
 	 									
							        	}
 	 								
							        	
							        	public void onResume() {
							        		super.onResume();
							        		smsSentReceiver=new BroadcastReceiver() {
							        			
							        			@Override
							        			public void onReceive(Context arg0, Intent arg1) {
							        				// TODO Auto-generated method stub
							        				switch (getResultCode()) {
							        				case Activity.RESULT_OK:
							        					Toast.makeText(getBaseContext(), "SMS has been sent", Toast.LENGTH_SHORT).show();
							        					
							        					break;
							        				case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
							        					Toast.makeText(getBaseContext(), "Generic Failure", Toast.LENGTH_SHORT).show();
							        					break;
							        				case SmsManager.RESULT_ERROR_NO_SERVICE:
							        					Toast.makeText(getBaseContext(), "No Service", Toast.LENGTH_SHORT).show();
							        					break;
							        				case SmsManager.RESULT_ERROR_NULL_PDU:
							        					Toast.makeText(getBaseContext(), "Null PDU", Toast.LENGTH_SHORT).show();
							        					break;
							        				case SmsManager.RESULT_ERROR_RADIO_OFF:
							        					Toast.makeText(getBaseContext(), "Radio Off", Toast.LENGTH_SHORT).show();
							        					break;
							        				default:
							        					break;
							        				}
							        				
							        			}
							        		};
							        		smsDeliveredReceiver=new BroadcastReceiver() {
							        			
							        			@Override
							        			public void onReceive(Context arg0, Intent arg1) {
							        				// TODO Auto-generated method stub
							        				switch(getResultCode()) {
							        				case Activity.RESULT_OK:
							        					Toast.makeText(getBaseContext(), "SMS Delivered", Toast.LENGTH_SHORT).show();
							        					break;
							        				case Activity.RESULT_CANCELED:
							        					Toast.makeText(getBaseContext(), "SMS not delivered", Toast.LENGTH_SHORT).show();
							        					break;
							        				}
							        			}
							        		};
							        		registerReceiver(smsSentReceiver, new IntentFilter("SMS_SENT"));
							        		registerReceiver(smsDeliveredReceiver, new IntentFilter("SMS_DELIVERED"));
							        	};
							 @Override
							        	public void onPause() {
							        		super.onPause();
							        		unregisterReceiver(smsSentReceiver);
							        		unregisterReceiver(smsDeliveredReceiver);
							        	}
							        }